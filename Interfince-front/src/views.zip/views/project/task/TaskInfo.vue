<template>
    <div style="margin:35px">
        <!--工具条-->
        <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
            <el-form :inline="true" :model="filters" @submit.native.prevent>
                <el-form-item>
                    <el-input v-model.trim="filters.name" placeholder="名称" @keyup.enter.native="getTaskRecord"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="getTaskRecord">查询</el-button>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="getTask">新增任务</el-button>
                </el-form-item>
            </el-form>
        </el-col>
        <!--列表-->
        <el-table :data="project" highlight-current-row v-loading="listLoading" @selection-change="selsChange" style="width: 100%;">
            <el-table-column type="index" min-width="5%">
            </el-table-column>
            <el-table-column prop="name" label="任务名称" min-width="15%" sortable show-overflow-tooltip>
            </el-table-column>
            <el-table-column prop="type" label="任务类型" min-width="15%" sortable show-overflow-tooltip>
                 <template slot-scope="scope">
                        <a v-if="scope.row.type === 'circulation'">循环</a>
                        <a v-if="scope.row.type === 'timing'">定时</a>
                    </template>
            </el-table-column>
            <el-table-column prop="frequency" label="执行频率" min-width="10%" sortable show-overflow-tooltip>
            </el-table-column>
            <el-table-column prop="unit" label="时分秒" min-width="15%" sortable show-overflow-tooltip>
                <template slot-scope="scope">
                        <a v-if="scope.row.unit === 'm'">分</a>
                        <a v-if="scope.row.unit === 'h'">时</a>
                        <a v-if="scope.row.unit === 'd'">天</a>
                        <a v-if="scope.row.unit === 'w'">周</a>
                    </template>
            </el-table-column>
            <el-table-column prop="startTime" label="开始时间" min-width="15%" sortable show-overflow-tooltip>
            </el-table-column>
            <el-table-column prop="endTime" label="结束时间" min-width="15%" sortable show-overflow-tooltip>
            </el-table-column>
            <el-table-column label="操作" min-width="15%">
                <template slot-scope="scope">
                    <el-button type="primary" size="small" @click="GetTaskExecuteRecode(scope.row)">查看执行记录</el-button>
                    <el-button type="danger" size="small" @click="DelTask(scope.row)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>


        <!--新增界面-->
        <el-dialog title="定时任务" :visible.sync="taskVShow"  :close-on-click-modal="false" style="width: 70%; left: 15%">
            <el-form ref="form" :model="form" label-width="100px" :rules="formRules">
                <el-form-item label="任务名称：" prop="name">
                    <el-input v-model.trim="form.name" placeholder="请输入任务名称" style="width:50% "></el-input>
                </el-form-item>
                <el-form-item label="类型：" prop="type">
                    <el-select v-model="form.type" placeholder="请选择">
                        <el-option v-for="item in type" :key="item.value" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="间隔：" prop="frequency" v-if="form.type === 'circulation'">
                    <el-row :span="24">
                        <el-col :span="14">
                            <el-input v-model.number="form.frequency" placeholder="间隔"></el-input>
                        </el-col>
                        <el-col :span="5">
                            <el-select v-model="form.unit" placeholder="请选择">
                                <el-option v-for="item in unit" :key="item.value" :label="item.label" :value="item.value"></el-option>
                            </el-select>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item label="执行时间：" prop="timeArray" v-if="form.type === 'circulation'">
                    <el-date-picker  v-model="form.timeArray" type="datetimerange" :picker-options="pickerOptions2"
                                     range-separator="   至   " start-placeholder="开始日期" end-placeholder="结束日期" align="right" ></el-date-picker>
                </el-form-item>
                <el-form-item label="执行时间：" prop="time" v-if="form.type === 'timing'">
                    <el-date-picker v-model="form.time" type="datetime" placeholder="选择日期时间" :picker-options="pickerOptions1"></el-date-picker>
                </el-form-item>
                <el-form-item label="HOST：" prop="Host">
                    <el-select v-model="form.Host"  placeholder="测试环境">
                        <el-option v-for="(item,index) in Host" :key="index+''" :label="item.name" :value="item.id"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="选择用例集：" prop="Case">
                    <el-select v-model="sels" multiple placeholder="选择测试用例集">
                        <el-option v-for="(item,index) in Case" :key="index+''" :label="item.caseName" :value="item.id"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" :loading="editLoading" @click.native="addTask">创建</el-button>
                </el-form-item>
            </el-form>
        </el-dialog>

        <!--工具条-->
        <el-col :span="24" class="toolbar">
            <el-pagination layout="prev, pager, next" @current-change="handleCurrentChange" :page-size="10" :page-count="total" style="float:right;">
            </el-pagination>
        </el-col>
    </div>
</template>

<script>
    import $ from 'jquery'
    import moment from "moment"
    import { test,getHost,getCase,
   addTask,seachTask,delTask} from '../../../api/api'
    export default {
        data() {
            return {
                filters: {
                    name: ''
                },
                Case: [],
                total: 0,
                page: 1,
                listLoading: false,
                sels: [],//选中Case数据
                taskVShow: false,
                delLoading: false,
                disDel: true,
                TestStatus: false,
                form: {
                    name: "",
                    type: "circulation",
                    frequency: "",
                    unit: "m",
                    time: "",
                    timeArray: [],
                    Host: "",
                },
                formRules: {
                    name: [
                        { required: true, message: '请输入任务名称', trigger: 'blur' },
                        { min: 1, max: 50, message: '长度在 1 到 50 个字符', trigger: 'blur' }
                    ],
                    frequency: [
                        { type: "number", required: true, message: '请输入时间间隔' },
                    ],
                    timeArray: [
                        { type: "array", required: true, message: '请选择执行时间' },
                    ],
                    time: [
                        { required: true, message: '请选择执行时间'},
                    ],
                    Host: [
                        { required: true, message: '请选择测试域名'},
                    ],
                    type: [
                        { required: true, message: '请选择任务类型', trigger: 'blur' },
                    ],
                },
                Host: [],
                unit: [
                    {value: "m", label: "分"},
                    {value: "h", label: "时"},
                    {value: "d", label: "天"},
                    {value: "w", label: "周"},
                ],
                type: [ {value: "circulation", label: "循环"},
                    {value: "timing", label: "定时"},],
                pickerOptions1: {
                    disabledDate(time) {
                        return time.getTime() < Date.now() - 8.64e7;
                    }
                },
                pickerOptions2: {
                    disabledDate(time) {
                        return time.getTime() < Date.now() - 8.64e7;
                    },
                    shortcuts: [{
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            end.setTime(end.getTime() + 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            end.setTime(end.getTime() + 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近三个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            end.setTime(end.getTime() + 3600 * 1000 * 24 * 90);
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                },


            }
        },
        methods: {
            getTaskRecord() {
                this.listLoading = true;
                let self = this;
                let params = {
                    projectId: this.$route.params.project_id,
                    page: self.page,
                    name: self.filters.name
                };
                let headers = {
                    Authorization: 'Token ' + JSON.parse(sessionStorage.getItem('token'))
                };
                seachTask(headers, params).then(_data => {
                    let {msg, code, data} = _data;
                    self.listLoading = false;
                    if (code === '999999') {
                        self.total = data.total;
                        self.project = data.data
                    } else {
                        self.$message.error({
                            message: msg,
                            center: true,
                        })
                    }
                });
            },
            GetTaskExecuteRecode(rows){
                this.$router.push(
                    {name: '定时任务记录',
                    query: {taskName:rows.name}
                    });
                // console.log('sssss:',rows)
            },
            handleCurrentChange(val){
                  this.page = val;
                  this.getTaskRecord();
            },
            getTask() {
                let self = this;
                $.ajax({
                    type: "get",
                    url: test + "/api/automation/get_time_task",
                    async: true,
                    data: {
                        project_id: self.$route.params.project_id,
                    },
                    headers: {
                        Authorization: 'Token ' + JSON.parse(sessionStorage.getItem('token'))
                    },
                    timeout: 5000,
                    success: (data) => {
                        if (data.code === '999999') {
                            try {
                                self.form.name = data.data.name;
                                self.form.type = data.data.type;
                                self.form.frequency = data.data.frequency;
                                if (self.form.type === 'timing') {
                                    self.form.unit = 'm'
                                } else {
                                    self.form.unit = data.data.unit;
                                }
                                self.form.time = data.data.startTime;
                                self.form.timeArray = [data.data.startTime, data.data.endTime];
                                self.form.Host = data.data.Host;
                                self.disDel = false
                            } catch (e) {
                                self.form.name = "";
                                self.form.type = "circulation";
                                self.form.frequency = "";
                                self.form.unit = "m";
                                self.form.time = "";
                                self.form.timeArray = [];
                                self.form.Host = "";
                                self.disDel = true
                            }
                            self.taskVShow = true
                        } else {
                            self.$message.error({
                                message: data.msg,
                                center: true,
                            })
                        }
                    },
                    error: function () {
                        self.editLoading = false;
                        self.$message.error({
                            message: "失败",
                            center: true,
                        })
                    }
                })
            },
            addTask() {
                let self = this;
                this.$refs.form.validate((valid) => {
                    if (valid) {
                        this.$confirm('确认提交吗？', '提示', {}).then(() => {
                                self.editLoading = true;
                                let params = {
                                    project_id: Number(self.$route.params.project_id),
                                    Host_id: Number(self.form.Host),
                                    name: self.form.name,
                                    type: self.form.type,
                                    frequency: Number(self.form.frequency),
                                    unit: self.form.unit,
                                    case_id:self.sels
                                };
                                if (self.form.type === 'circulation') {
                                    params['startTime'] = moment(self.form.timeArray[0]).format("YYYY-MM-DD HH:mm:ss");
                                    params['endTime'] = moment(self.form.timeArray[1]).format("YYYY-MM-DD HH:mm:ss")
                                } else {
                                    params['startTime'] = moment(self.form.time).format("YYYY-MM-DD HH:mm:ss");
                                    params['endTime'] = moment(self.form.time).format("YYYY-MM-DD HH:mm:ss")
                                };
                                let headers = {Authorization: 'Token '+JSON.parse(sessionStorage.getItem('token'))};
                                console.log(params);
                                addTask(headers,params).then(_data =>{
                                    let {code,msg,data} =_data;
                                    if (code ==='999999'){
                                        self.editLoading = false;
                                        self.taskVShow = false;
                                        self.$message({
                                            message: '添加成功',
                                            center: true,
                                            type: "success",
                                         });
                                        this.getTaskRecord()
                                    }
                                    else {
                                        self.editLoading = false;
                                        self.$message.error({
                                                message: msg,
                                                center: true,
                                        })
                                    }}
                                )

                            }
                        )
                    }
                })
            },
            GetHost() {
                let self = this;
                let params = {project_id: this.$route.params.project_id, page: this.page,};
                let headers = {Authorization: 'Token ' + JSON.parse(sessionStorage.getItem('token'))};
                getHost(headers, params).then(_data => {
                        if (_data.code === '999999') {
                            _data.data.data.forEach((item) => {
                                if (item.status) {
                                    self.Host.push(item)
                                }
                            });
                        } else {
                            self.$message.error({
                                message: data.msg,
                                center: true,
                            })
                        }
                    },
                )
            },
            GetCase() {
                let self = this;
                let params = {project_id: this.$route.params.project_id};
                let headers = {Authorization: 'Token ' + JSON.parse(sessionStorage.getItem('token'))};
                getCase(headers, params).then(_data => {
                        if (_data.code === '999999') {
                            _data.data.data.forEach((item) => {
                                if (item.caseName) {
                                    self.Case.push(item)
                                }
                            });
                            console.log(self.Case);
                        } else {
                            self.$message.error({
                                message: data.msg,
                                center: true,
                            })
                        }
                    },
                )
            },
            DelTask(row) {
                let self = this;
                self.delLoading = true;
                let params = {
                    project_id: Number(self.$route.params.project_id),
                    taskName:row.name,
                };
                let headers= { "Content-Type": "application/json",
                                Authorization: 'Token ' + JSON.parse(sessionStorage.getItem('token'))
                            };
                console.log(params);
                delTask(headers,params).then(_data => {
                    if (_data.code === '999999') {
                        self.delLoading = false;
                        self.taskVShow = false;
                        self.$message({
                            message: "删除成功",
                            center: true,
                            type: "success"
                        });
                        this.getTaskRecord()
                    } else {
                        self.delLoading = false;
                        self.$message.error({
                            message: _data.msg,
                            center: true,
                        })
                    }
                })
            },
        },
        mounted() {
            this.getTaskRecord();
            this.GetHost();
            this.GetCase();

        }

    }

</script>
<style>
</style>
