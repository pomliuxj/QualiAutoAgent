<template>
    <div style="margin:35px">

        <!--列表-->
        <el-table :data="tableData" highlight-current-row  style="width: 100%;">
            <el-table-column type="index" min-width="5%">
            </el-table-column>
            <el-table-column prop="taskName" label="任务名称" min-width="15%" sortable show-overflow-tooltip>
            </el-table-column>
            <el-table-column prop="taskResult" label="任务是否成功" min-width="15%" sortable show-overflow-tooltip>
                 <template slot-scope="scope">
                        <a v-if="scope.row.taskResult === true">成功</a>
                        <a v-if="scope.row.taskResult === false">失败</a>
                 </template>
            </el-table-column>
            <el-table-column prop="id" label="执行任务id" min-width="10%" sortable show-overflow-tooltip>
            </el-table-column>
            <el-table-column prop="elapsedTime" label="任务持续时间" min-width="15%" sortable show-overflow-tooltip>
            </el-table-column>
            <el-table-column prop="startTime" label="执行时间" min-width="15%" sortable show-overflow-tooltip>
            </el-table-column>
            <el-table-column prop="project" label="所属项目" min-width="15%" sortable show-overflow-tooltip>
            </el-table-column>
        </el-table>

        <!--工具条-->
        <el-col :span="24" class="toolbar">
            <el-pagination layout="prev, pager, next" @current-change="handleCurrentChange" :page-size="10" :page-count="total" style="float:right;">
            </el-pagination>
        </el-col>
    </div>
</template>

<script>

    import { test,TaskRecode} from '../../../api/api'
    export default {
        data(){
            return {
                tableData: [],
                total:0,
                page:1
            }
        },
        methods: {
            handleCurrentChange(val){
                  this.page = val;
                  this.getTaskExecuteRecord();
                  },

            getTaskExecuteRecord() {
                let self = this;
                let params = {taskName:this.$route.query.taskName,
                                page: self.page,
 };
                let headers = {Authorization: 'Token ' + JSON.parse(sessionStorage.getItem('token'))};
                TaskRecode(headers, params).then(_data => {
                        if (_data.code === '999999') {
                            self.tableData=_data.data.data;
                            self.total=_data.data.total
                            console.log(self.tableData);
                        } else {
                            self.$message.error({
                                message: data.msg,
                                center: true,
                            })
                        }
                    },
                )
            },

        },
        mounted() {
            this.getTaskExecuteRecord();
        }

    }

</script>
<style>
</style>
