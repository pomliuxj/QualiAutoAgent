<template>
    <el-container>
        <el-header style="background-color: #F7F7F7;; padding: 0; height: 50px;">
            <div style="padding-top: 10px; margin-left: 600px; ">
                <el-row>
                    <el-col :span="15">
                        <el-button
                            type="primary"
                            size="small"
                            icon="el-icon-circle-check-outline"
                            @click="handleConfirm"
                            round
                        >
                            点击保存
                        </el-button>
                        <el-button
                            icon="el-icon-circle-check-outline"
                            type="info"
                            size="small"
                            @click="handleRunCode"
                            round
                        >
                            在线运行
                       </el-button>
                    </el-col>

                </el-row>
            </div>

        </el-header>

        <el-container>
          <el-aside width="300px" style="background-color: rgb(238, 241, 246)">
              <el-input v-model="variablesname"  placeholder="创建新变量名称" style="width:100% " clearable>
              </el-input>
                    <el-menu default-active="2" class="el-menu-vertical-demo" active-text-color="rgb(32, 160, 255)" :unique-opened="true">
                        <template v-for="(item,index) in variablesData">
                                        <el-menu-item :index="index+''" :key="item.id" @click="setSelectValue(item.variablesName)" class="group">
                                            <div slot="title">
                                                {{item.variablesName}}
                                            </div>
                                        </el-menu-item>
                                </template>
                    </el-menu>
          </el-aside>

          <el-main style="width:100% ;margin-right: 200px">
                <el-row>
                    <el-col :span="12">
                         <h2 style="color: #20a0ff;">代码编辑器 </h2>
                        <editor
                            v-model="code"
                            @init="editorInit"
                            lang="python"
                            theme="monokai"
                            width="100%"
                            :height="codeHeight"
                            :options="{
                                 enableSnippets:true,
                                 enableBasicAutocompletion: true,
                                 enableLiveAutocompletion: true
                             }"
                        >
                        </editor>
                    </el-col>

                    <el-col :span="12" v-show="debugshow">
                        <h2 style="color: #20a0ff">调试控制台 </h2>
                        <editor
                            v-model="resp.data"
                            lang="text"
                            theme="monokai"
                            width="100%"
                            :height="codeHeight"
                        >
                        </editor>
                    </el-col>
                </el-row>

            </el-main>
        </el-container>
    </el-container>


</template>

<script>
    import { CreateVariables,GetVariables,RunVariables,UpdateVariables} from '../../../api/api'
    export default {

        data() {
            return {
                codeHeight: 500,
                debugshow:false,
                variablesData:'',
                code: '#在线代码',
                variablesname:'',
                newvariablesname:'',
                resp: {
                    data: ''
                }
            }
        },
        methods: {
            handleRunCode() {
                 this.debugshow= true
                 this.resp.msg = '';
                 let headers = {
                    Authorization: 'Token '+JSON.parse(sessionStorage.getItem('token'))
                };
                 let params ={
                     Code:this.code,
                     variablesName:this.variablesname
                 }
                RunVariables(headers,params).then(resp => {
                    this.resp = resp.data;
                })
            },

            handleConfirm() {
                let headers = {
                    Authorization: 'Token '+JSON.parse(sessionStorage.getItem('token'))
                };
                let params ={
                    project_id: Number(this.$route.params.project_id),
                    variablesName:this.variablesname,
                    Code:this.code,
                };
                UpdateVariables(headers,params).then(resp =>{
                    if (resp.code ==='999999'){
                        this.$message({
                                    message: '保存成功',
                                    center: true,
                                    type: "success",
                                 });
                        this.getVariablesList();
                    }else {
                        this.$message.error({
                                    message:resp.msg ,
                                    center: true,
                                 });
                    }

                    }
                )

            },
            editorInit() {
                require('brace/ext/language_tools');
                require('brace/mode/python');
                require('brace/theme/monokai');
                require('brace/snippets/python');
            },
            getVariablesList() {
              let headers = {
                    Authorization: 'Token '+JSON.parse(sessionStorage.getItem('token'))
                };
                GetVariables(headers).then(res => {
                    this.variablesData = res.data.data;
                    console.log(this.variablesData)
                })
            },

            setSelectValue(name){
                this.variablesname = name;
                this.debugshow=false
                let headers = {
                    Authorization: 'Token '+JSON.parse(sessionStorage.getItem('token'))
                };
                let params = {
                    variablesName : this.variablesname
                };
                GetVariables(headers,params).then(res => {
                    this.code=res.data.data[0].Code;
                    console.log("赋值code:",this.code);
                })

            },
            handleCreate(){
             let headers = {
                    Authorization: 'Token '+JSON.parse(sessionStorage.getItem('token'))
                };
             let params ={
                    project_id: Number(this.$route.params.project_id),
                    variablesName:this.variablesname,
                    Code:this.code,
                };
             CreateVariables(headers,params).then(res =>{
                     if (res.code ==='999999'){
                        this.$message({
                        message: '保存成功',
                        center: true,
                        type: "success",
                     });
                     }else {
                     this.$message({
                        message: res.msg,
                        center: true,
                        });
                        }
                    }
                )
            }

        },
        components: {
            editor: require('vue2-ace-editor')
        },
        mounted() {
            this.getVariablesList();
        }
    }
</script>

<style scoped>

    .ace_editor {
        position: relative;
        overflow: hidden;
        font: 18px/normal 'Monaco', 'Menlo', 'Ubuntu Mono', 'Consolas', 'source-code-pro', monospace !important;
        direction: ltr;
        text-align: left;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    }

</style>

