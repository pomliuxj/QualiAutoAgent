<template>
    <div class = "container">
        <iframe src="../../static/自动化平台.pdf" width="85%" height="100%" allowfullscreen="true"  onload="document.all['makewing'].style.height=makewing.document.body.scrollHeight">
        </iframe>
     </div>
</template>